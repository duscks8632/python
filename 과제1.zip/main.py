import random
def insertion_sort(arr):
    # 배열의 두 번째 요소부터 시작
    for i in range(1, arr.length):
        key = arr[i]
        # key가 들어갈 위치를 찾기 위해 왼쪽 요소들과 비교
        j = i - 1
        #왼쪽부분은 다 정렬된 상태라 왼쪽부분에서 가장 오른쪽거만 비교하면 됨
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]  # 요소를 오른쪽으로 이동
            j -= 1
        arr[j + 1] = key  # key를 올바른 위치에 삽입
    return arr



# arr1: 1부터 10000000까지 순서대로 증가하는 배열
arr1 = list(range(1, 10000001))

# arr2: 10000000부터 1까지 순서대로 감소하는 배열
arr2 = list(range(10000000, 0, -1))

# arr3: 1부터 10000000까지의 숫자를 무작위로 섞은 배열
arr3 = list(range(1, 10000001))
random.shuffle(arr3)

sorted_arr1 = insertion_sort(arr1)
sorted_arr2 = insertion_sort(arr2)
sorted_arr3 = insertion_sort(arr3)

print(sorted_arr1)
print(sorted_arr2)
print(sorted_arr3)